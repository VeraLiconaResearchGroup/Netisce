#!/bin/bash -ue
SFA_exp_attr_mut.py network.sif expressions.csv attrs_exp.txt mutations.csv
