#!/bin/bash -ue
get_RONs.py attrs_exp.txt internal_marker.txt
